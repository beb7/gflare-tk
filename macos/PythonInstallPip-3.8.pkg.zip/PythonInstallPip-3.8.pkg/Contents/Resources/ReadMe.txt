This package installs (or upgrades from an earlier version)
pip, a tool for installing and managing Python packages.
