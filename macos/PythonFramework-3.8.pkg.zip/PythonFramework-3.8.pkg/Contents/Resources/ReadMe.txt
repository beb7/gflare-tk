This package installs Python.framework, that is the python
interpreter and the standard library.
